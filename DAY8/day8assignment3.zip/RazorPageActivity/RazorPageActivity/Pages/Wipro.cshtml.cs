using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPageActivity.Pages
{
    public class WiproModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
